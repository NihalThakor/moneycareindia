import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import InvestorCharter from './pages/InvestorCharter';
import MITC from './pages/MITC';
import Downloads from './pages/Downloads';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/investor-charter" element={<InvestorCharter />} />
          <Route path="/mitc" element={<MITC />} />
          <Route path="/downloads" element={<Downloads />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;