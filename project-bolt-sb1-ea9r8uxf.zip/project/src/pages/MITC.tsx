import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { FileText, Download, AlertTriangle, Info } from 'lucide-react';

const MITC: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      <Header currentPage="mitc" />
      
      <div className="pt-32 pb-20">
        <div className="container mx-auto px-4">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              Most Important <span className="text-blue-600">Terms & Conditions</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Essential terms and conditions that govern your relationship with Moneycare India
            </p>
          </div>

          {/* Main Content */}
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden">
              {/* Header */}
              <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6">
                <div className="flex items-center space-x-3">
                  <FileText className="w-8 h-8" />
                  <div>
                    <h2 className="text-2xl font-bold">Most Important Terms & Conditions</h2>
                    <p className="text-blue-100">Please read these terms carefully before proceeding</p>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-8 space-y-8">
                {/* Important Notice */}
                <div className="bg-red-50 border border-red-200 p-6 rounded-lg">
                  <div className="flex items-start space-x-3">
                    <AlertTriangle className="w-6 h-6 text-red-600 mt-1 flex-shrink-0" />
                    <div>
                      <h3 className="text-lg font-semibold text-red-800 mb-2">Important Notice</h3>
                      <p className="text-red-700">
                        These terms and conditions are legally binding. By opening an account or availing services from Moneycare India, 
                        you agree to be bound by these terms. Please read them carefully and contact us if you have any questions.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Account Opening */}
                <section>
                  <h3 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
                    <Info className="w-6 h-6 mr-2 text-blue-600" />
                    Account Opening & KYC Requirements
                  </h3>
                  <div className="bg-blue-50 p-6 rounded-lg space-y-4">
                    <ul className="text-gray-700 space-y-3">
                      <li className="flex items-start">
                        <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-3 mt-0.5 flex-shrink-0">1</span>
                        <span>All clients must complete KYC (Know Your Customer) requirements as per SEBI guidelines before account activation.</span>
                      </li>
                      <li className="flex items-start">
                        <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-3 mt-0.5 flex-shrink-0">2</span>
                        <span>Clients must provide accurate and complete information during account opening. Any false or misleading information may lead to account termination.</span>
                      </li>
                      <li className="flex items-start">
                        <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-3 mt-0.5 flex-shrink-0">3</span>
                        <span>Account activation is subject to verification of documents and approval by our compliance team.</span>
                      </li>
                      <li className="flex items-start">
                        <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-3 mt-0.5 flex-shrink-0">4</span>
                        <span>Clients must update their information immediately in case of any changes in personal details, contact information, or financial status.</span>
                      </li>
                    </ul>
                  </div>
                </section>

                {/* Trading Terms */}
                <section>
                  <h3 className="text-2xl font-semibold text-gray-900 mb-4">Trading Terms & Conditions</h3>
                  <div className="space-y-6">
                    <div className="bg-green-50 p-6 rounded-lg">
                      <h4 className="font-semibold text-green-800 mb-3">Trading Authorization & Limits</h4>
                      <ul className="text-gray-700 space-y-2">
                        <li>• All trades are subject to available trading limits and margin requirements</li>
                        <li>• Clients are responsible for maintaining adequate margins at all times</li>
                        <li>• We reserve the right to close positions in case of margin shortfall</li>
                        <li>• Trading limits may be revised based on client's financial profile and market conditions</li>
                      </ul>
                    </div>

                    <div className="bg-orange-50 p-6 rounded-lg">
                      <h4 className="font-semibold text-orange-800 mb-3">Risk Disclosure & Client Responsibility</h4>
                      <ul className="text-gray-700 space-y-2">
                        <li>• Trading in securities involves substantial risk and may not be suitable for all investors</li>
                        <li>• Past performance is not indicative of future results</li>
                        <li>• Clients are solely responsible for their trading decisions and resulting profits/losses</li>
                        <li>• Moneycare India does not guarantee profits or protect against losses</li>
                      </ul>
                    </div>
                  </div>
                </section>

                {/* Fees & Charges */}
                <section>
                  <h3 className="text-2xl font-semibold text-gray-900 mb-4">Fees & Charges</h3>
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold text-gray-800 mb-3">Brokerage & Transaction Charges</h4>
                        <ul className="text-gray-700 space-y-1 text-sm">
                          <li>• Brokerage charges as per agreed schedule</li>
                          <li>• Exchange transaction charges</li>
                          <li>• SEBI turnover charges</li>
                          <li>• Stamp duty and other statutory charges</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800 mb-3">Account Maintenance</h4>
                        <ul className="text-gray-700 space-y-1 text-sm">
                          <li>• Annual maintenance charges (if applicable)</li>
                          <li>• Demat account charges</li>
                          <li>• Statement and certificate charges</li>
                          <li>• Other service charges as applicable</li>
                        </ul>
                      </div>
                    </div>
                    <div className="mt-4 p-4 bg-yellow-100 rounded border-l-4 border-yellow-500">
                      <p className="text-yellow-800 text-sm">
                        <strong>Note:</strong> All charges are subject to change with prior notice. Detailed fee schedule is available on our website and in client agreements.
                      </p>
                    </div>
                  </div>
                </section>

                {/* Liability & Indemnity */}
                <section>
                  <h3 className="text-2xl font-semibold text-gray-900 mb-4">Liability & Indemnity</h3>
                  <div className="bg-red-50 p-6 rounded-lg space-y-4">
                    <p className="text-gray-700">
                      <strong>Limitation of Liability:</strong> Moneycare India's liability is limited to the actual loss caused due to our negligence or default. 
                      We are not liable for any consequential, indirect, or special damages.
                    </p>
                    <p className="text-gray-700">
                      <strong>Client Indemnity:</strong> Clients agree to indemnify and hold harmless Moneycare India from any claims, losses, or damages arising from:
                    </p>
                    <ul className="text-gray-700 space-y-2 ml-4">
                      <li>• Unauthorized use of account or trading credentials</li>
                      <li>• Non-compliance with regulatory requirements</li>
                      <li>• Misrepresentation of information or documents</li>
                      <li>• Violation of terms and conditions</li>
                    </ul>
                  </div>
                </section>

                {/* Termination */}
                <section>
                  <h3 className="text-2xl font-semibold text-gray-900 mb-4">Account Termination</h3>
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <p className="text-gray-700 mb-4">
                      Either party may terminate the relationship with 30 days written notice. Immediate termination may occur in cases of:
                    </p>
                    <ul className="text-gray-700 space-y-2">
                      <li>• Breach of terms and conditions</li>
                      <li>• Non-payment of dues</li>
                      <li>• Regulatory non-compliance</li>
                      <li>• Suspicious or fraudulent activities</li>
                    </ul>
                    <p className="text-gray-700 mt-4">
                      Upon termination, all pending obligations must be settled, and securities will be transferred as per client instructions.
                    </p>
                  </div>
                </section>

                {/* Contact & Grievance */}
                <section>
                  <h3 className="text-2xl font-semibold text-gray-900 mb-4">Contact & Grievance Redressal</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-blue-50 p-6 rounded-lg">
                      <h4 className="font-semibold text-blue-800 mb-3">For Queries & Support</h4>
                      <div className="space-y-2 text-gray-700">
                        <p>Email: info@moneycareindia.co.in</p>
                        <p>Phone: +91-22-6234-5678</p>
                        <p>Address: 50-A, 3rd Floor, Perin Nariman Street, Mumbai</p>
                      </div>
                    </div>
                    <div className="bg-green-50 p-6 rounded-lg">
                      <h4 className="font-semibold text-green-800 mb-3">For Complaints</h4>
                      <div className="space-y-2 text-gray-700">
                        <p>Email: complaint@moneycareindia.in</p>
                        <p>SEBI SCORES: scores.sebi.gov.in</p>
                        <p>Compliance Officer: Mr. Manish Thakor</p>
                      </div>
                    </div>
                  </div>
                </section>

                {/* Download Section */}
                <section className="border-t pt-8">
                  <h3 className="text-2xl font-semibold text-gray-900 mb-4">Download Complete Document</h3>
                  <a
                    href="#"
                    download="most-important-terms-conditions.pdf"
                    className="inline-flex items-center p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors duration-300 group"
                  >
                    <Download className="w-6 h-6 text-blue-600 mr-3 group-hover:text-blue-800" />
                    <div>
                      <h4 className="font-semibold text-blue-800">Complete Terms & Conditions</h4>
                      <p className="text-blue-600 text-sm">PDF Document (Detailed Version)</p>
                    </div>
                  </a>
                </section>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default MITC;