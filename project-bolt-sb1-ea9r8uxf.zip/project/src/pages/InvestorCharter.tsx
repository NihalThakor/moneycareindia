import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Download, FileText, Shield, AlertCircle } from 'lucide-react';

const InvestorCharter: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      <Header currentPage="investor-charter" />
      
      <div className="pt-32 pb-20">
        <div className="container mx-auto px-4">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              Investor Charter - <span className="text-blue-600">Depository</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Your rights and obligations as an investor with Moneycare India's depository services
            </p>
          </div>

          {/* Main Content */}
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden">
              {/* Header */}
              <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6">
                <div className="flex items-center space-x-3">
                  <Shield className="w-8 h-8" />
                  <div>
                    <h2 className="text-2xl font-bold">Investor Charter - Depository Services</h2>
                    <p className="text-blue-100">Central Depository Services Limited (CDSL)</p>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-8 space-y-8">
                {/* Vision & Mission */}
                <section>
                  <h3 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
                    <FileText className="w-6 h-6 mr-2 text-blue-600" />
                    Vision & Mission
                  </h3>
                  <div className="bg-blue-50 p-6 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Vision:</h4>
                    <p className="text-gray-700 mb-4">
                      To be the most trusted and efficient depository, providing innovative solutions and services to all market participants.
                    </p>
                    <h4 className="font-semibold text-blue-800 mb-2">Mission:</h4>
                    <p className="text-gray-700">
                      To provide reliable, secure and efficient depository services through continuous innovation in processes and technology.
                    </p>
                  </div>
                </section>

                {/* Investor Rights */}
                <section>
                  <h3 className="text-2xl font-semibold text-gray-900 mb-4">Your Rights as an Investor</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-green-50 p-6 rounded-lg">
                      <h4 className="font-semibold text-green-800 mb-3">Account Operations</h4>
                      <ul className="text-gray-700 space-y-2">
                        <li>• Right to receive account statements</li>
                        <li>• Right to receive transaction confirmations</li>
                        <li>• Right to freeze/defreeze your account</li>
                        <li>• Right to change account details</li>
                      </ul>
                    </div>
                    <div className="bg-blue-50 p-6 rounded-lg">
                      <h4 className="font-semibold text-blue-800 mb-3">Information & Services</h4>
                      <ul className="text-gray-700 space-y-2">
                        <li>• Right to timely and accurate information</li>
                        <li>• Right to receive corporate benefits</li>
                        <li>• Right to participate in e-voting</li>
                        <li>• Right to grievance redressal</li>
                      </ul>
                    </div>
                  </div>
                </section>

                {/* Investor Obligations */}
                <section>
                  <h3 className="text-2xl font-semibold text-gray-900 mb-4">Your Obligations as an Investor</h3>
                  <div className="bg-orange-50 p-6 rounded-lg">
                    <ul className="text-gray-700 space-y-3">
                      <li className="flex items-start">
                        <AlertCircle className="w-5 h-5 text-orange-600 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Provide complete and accurate information during account opening</span>
                      </li>
                      <li className="flex items-start">
                        <AlertCircle className="w-5 h-5 text-orange-600 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Keep your account details updated, especially contact information</span>
                      </li>
                      <li className="flex items-start">
                        <AlertCircle className="w-5 h-5 text-orange-600 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Verify all transaction statements and report discrepancies immediately</span>
                      </li>
                      <li className="flex items-start">
                        <AlertCircle className="w-5 h-5 text-orange-600 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Safeguard your account credentials and transaction passwords</span>
                      </li>
                      <li className="flex items-start">
                        <AlertCircle className="w-5 h-5 text-orange-600 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Pay applicable charges and fees as per the schedule</span>
                      </li>
                    </ul>
                  </div>
                </section>

                {/* Services Details */}
                <section>
                  <h3 className="text-2xl font-semibold text-gray-900 mb-4">Depository Services</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-white border border-gray-200 p-6 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-3">Account Services</h4>
                      <ul className="text-gray-600 space-y-1 text-sm">
                        <li>• Demat Account Opening</li>
                        <li>• Account Maintenance</li>
                        <li>• Nomination Facility</li>
                        <li>• Account Closure</li>
                      </ul>
                    </div>
                    <div className="bg-white border border-gray-200 p-6 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-3">Transaction Services</h4>
                      <ul className="text-gray-600 space-y-1 text-sm">
                        <li>• Dematerialization</li>
                        <li>• Rematerialization</li>
                        <li>• Transfer of Securities</li>
                        <li>• Pledge/Unpledge</li>
                      </ul>
                    </div>
                    <div className="bg-white border border-gray-200 p-6 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-3">Corporate Services</h4>
                      <ul className="text-gray-600 space-y-1 text-sm">
                        <li>• Dividend Distribution</li>
                        <li>• Bonus/Rights Issues</li>
                        <li>• Stock Splits</li>
                        <li>• E-voting Services</li>
                      </ul>
                    </div>
                  </div>
                </section>

                {/* Grievance Redressal */}
                <section>
                  <h3 className="text-2xl font-semibold text-gray-900 mb-4">Grievance Redressal</h3>
                  <div className="bg-red-50 p-6 rounded-lg">
                    <p className="text-gray-700 mb-4">
                      If you have any complaints or grievances, you can approach us through the following channels:
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-semibold text-red-800 mb-2">Primary Contact:</h4>
                        <p className="text-gray-700">Email: complaint@moneycareindia.in</p>
                        <p className="text-gray-700">Phone: +91-22-6234-5678</p>
                      </div>
                      <div>
                        <h4 className="font-semibold text-red-800 mb-2">SEBI SCORES:</h4>
                        <p className="text-gray-700">Register and file complaints at</p>
                        <a href="https://scores.sebi.gov.in/" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800">
                          https://scores.sebi.gov.in/
                        </a>
                      </div>
                    </div>
                  </div>
                </section>

                {/* Download Section */}
                <section className="border-t pt-8">
                  <h3 className="text-2xl font-semibold text-gray-900 mb-4">Download Documents</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <a
                      href="#"
                      download="investor-charter-depository.pdf"
                      className="flex items-center p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors duration-300 group"
                    >
                      <Download className="w-6 h-6 text-blue-600 mr-3 group-hover:text-blue-800" />
                      <div>
                        <h4 className="font-semibold text-blue-800">Complete Investor Charter</h4>
                        <p className="text-blue-600 text-sm">PDF Document</p>
                      </div>
                    </a>
                    <a
                      href="#"
                      download="depository-services-guide.pdf"
                      className="flex items-center p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-colors duration-300 group"
                    >
                      <Download className="w-6 h-6 text-green-600 mr-3 group-hover:text-green-800" />
                      <div>
                        <h4 className="font-semibold text-green-800">Services Guide</h4>
                        <p className="text-green-600 text-sm">PDF Document</p>
                      </div>
                    </a>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default InvestorCharter;