import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Download, FileText, Shield, AlertTriangle, Info, CheckCircle } from 'lucide-react';

const Downloads: React.FC = () => {
  const downloadCategories = [
    {
      title: 'Account Opening Forms',
      icon: <FileText className="w-6 h-6" />,
      color: 'blue',
      items: [
        { name: 'Individual Account Opening Form', file: 'individual-account-form.pdf' },
        { name: 'Corporate Account Opening Form', file: 'corporate-account-form.pdf' },
        { name: 'Partnership Account Opening Form', file: 'partnership-account-form.pdf' },
        { name: 'HUF Account Opening Form', file: 'huf-account-form.pdf' }
      ]
    },
    {
      title: 'KYC Documents',
      icon: <Shield className="w-6 h-6" />,
      color: 'green',
      items: [
        { name: 'KYC Application Form', file: 'kyc-application-form.pdf' },
        { name: 'KYC Modification Form', file: 'kyc-modification-form.pdf' },
        { name: 'In-Person Verification Form', file: 'ipv-form.pdf' },
        { name: 'KYC Guidelines', file: 'kyc-guidelines.pdf' }
      ]
    },
    {
      title: 'Risk Disclosure & Legal Documents',
      icon: <AlertTriangle className="w-6 h-6" />,
      color: 'red',
      items: [
        { name: 'Risk Disclosure Document', file: 'risk-disclosure.pdf' },
        { name: 'Rights & Obligations', file: 'rights-obligations.pdf' },
        { name: 'Terms & Conditions', file: 'terms-conditions.pdf' },
        { name: 'Privacy Policy', file: 'privacy-policy.pdf' }
      ]
    },
    {
      title: 'Trading & Investment',
      icon: <Info className="w-6 h-6" />,
      color: 'purple',
      items: [
        { name: 'Tariff Sheet', file: 'tariff-sheet.pdf' },
        { name: 'Margin Policy', file: 'margin-policy.pdf' },
        { name: 'Trading Guidelines', file: 'trading-guidelines.pdf' },
        { name: 'Investment Advisory Agreement', file: 'advisory-agreement.pdf' }
      ]
    },
    {
      title: 'Policies & Procedures',
      icon: <CheckCircle className="w-6 h-6" />,
      color: 'orange',
      items: [
        { name: 'Grievance Redressal Policy', file: 'grievance-policy.pdf' },
        { name: 'Anti-Money Laundering Policy', file: 'aml-policy.pdf' },
        { name: 'Code of Conduct', file: 'code-of-conduct.pdf' },
        { name: 'Investor Charter', file: 'investor-charter.pdf' }
      ]
    },
    {
      title: 'Forms & Applications',
      icon: <FileText className="w-6 h-6" />,
      color: 'indigo',
      items: [
        { name: 'Complaint Form', file: 'complaint-form.pdf' },
        { name: 'Account Closure Form', file: 'closure-form.pdf' },
        { name: 'Nomination Form', file: 'nomination-form.pdf' },
        { name: 'Power of Attorney Form', file: 'poa-form.pdf' }
      ]
    }
  ];

  const getColorClasses = (color: string) => {
    const colorMap = {
      blue: 'bg-blue-50 border-blue-200 text-blue-800',
      green: 'bg-green-50 border-green-200 text-green-800',
      red: 'bg-red-50 border-red-200 text-red-800',
      purple: 'bg-purple-50 border-purple-200 text-purple-800',
      orange: 'bg-orange-50 border-orange-200 text-orange-800',
      indigo: 'bg-indigo-50 border-indigo-200 text-indigo-800'
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.blue;
  };

  const getIconColorClasses = (color: string) => {
    const colorMap = {
      blue: 'text-blue-600',
      green: 'text-green-600',
      red: 'text-red-600',
      purple: 'text-purple-600',
      orange: 'text-orange-600',
      indigo: 'text-indigo-600'
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.blue;
  };

  return (
    <div className="min-h-screen bg-white">
      <Header currentPage="downloads" />
      
      <div className="pt-32 pb-20">
        <div className="container mx-auto px-4">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              Downloads & <span className="text-blue-600">Documents</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Access all important forms, documents, and resources for your investment journey with Moneycare India
            </p>
          </div>

          {/* Important Notice */}
          <div className="bg-yellow-50 border border-yellow-200 p-6 rounded-lg mb-12">
            <div className="flex items-start space-x-3">
              <AlertTriangle className="w-6 h-6 text-yellow-600 mt-1 flex-shrink-0" />
              <div>
                <h3 className="text-lg font-semibold text-yellow-800 mb-2">Important Notice</h3>
                <p className="text-yellow-700">
                  Please ensure you download the latest versions of all forms and documents. All forms must be filled completely 
                  and submitted with required supporting documents. For any assistance, please contact our customer support team.
                </p>
              </div>
            </div>
          </div>

          {/* Download Categories */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {downloadCategories.map((category, index) => (
              <div key={index} className={`border rounded-lg p-6 ${getColorClasses(category.color)}`}>
                <div className="flex items-center space-x-3 mb-6">
                  <div className={`${getIconColorClasses(category.color)}`}>
                    {category.icon}
                  </div>
                  <h3 className="text-xl font-semibold">{category.title}</h3>
                </div>
                
                <div className="space-y-3">
                  {category.items.map((item, itemIndex) => (
                    <a
                      key={itemIndex}
                      href="#"
                      download={item.file}
                      className="flex items-center justify-between p-3 bg-white rounded-lg hover:shadow-md transition-all duration-300 group"
                    >
                      <div className="flex items-center space-x-3">
                        <FileText className="w-4 h-4 text-gray-500 group-hover:text-blue-600 transition-colors" />
                        <span className="text-gray-700 group-hover:text-blue-600 transition-colors">
                          {item.name}
                        </span>
                      </div>
                      <Download className="w-4 h-4 text-gray-400 group-hover:text-blue-600 transition-colors" />
                    </a>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Additional Information */}
          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-blue-50 p-6 rounded-lg text-center">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Info className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-lg font-semibold text-blue-800 mb-2">Need Help?</h4>
              <p className="text-blue-700 text-sm mb-4">
                Our customer support team is available to assist you with any document-related queries.
              </p>
              <a href="/contact" className="text-blue-600 hover:text-blue-800 font-medium">
                Contact Support →
              </a>
            </div>

            <div className="bg-green-50 p-6 rounded-lg text-center">
              <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-lg font-semibold text-green-800 mb-2">Document Verification</h4>
              <p className="text-green-700 text-sm mb-4">
                All documents are verified and processed within 2-3 business days of submission.
              </p>
              <a href="#" className="text-green-600 hover:text-green-800 font-medium">
                Track Status →
              </a>
            </div>

            <div className="bg-orange-50 p-6 rounded-lg text-center">
              <div className="w-12 h-12 bg-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-lg font-semibold text-orange-800 mb-2">Secure & Compliant</h4>
              <p className="text-orange-700 text-sm mb-4">
                All forms and processes are SEBI compliant and follow industry security standards.
              </p>
              <a href="#" className="text-orange-600 hover:text-orange-800 font-medium">
                Learn More →
              </a>
            </div>
          </div>

          {/* Contact Information */}
          <div className="mt-16 bg-gray-50 p-8 rounded-lg">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-semibold text-gray-900 mb-2">Still Have Questions?</h3>
              <p className="text-gray-600">
                Our team is here to help you with any document or form-related queries.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Email Support</h4>
                <a href="mailto:info@moneycareindia.co.in" className="text-blue-600 hover:text-blue-800">
                  info@moneycareindia.co.in
                </a>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Phone Support</h4>
                <a href="tel:+91-22-6234-5678" className="text-blue-600 hover:text-blue-800">
                  +91-22-6234-5678
                </a>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Office Hours</h4>
                <p className="text-gray-600">Mon - Fri: 9:00 AM - 6:00 PM</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Downloads;